<?php
/** @var \WDIP\Plugin\Viewer $this */
/** @var \WDIP\Plugin\ObjectData $options */

$options = $this->getOptions();
?>


<div id="fsc-plugin-chart-<?= $options->uid; ?>" class="bordering">
    <div class="chart-head">
        <button class="fsc-btn btn-link text-info pos-right">
            <i class="fa fa-cog" aria-hidden="true"></i>
        </button>
    </div>
    <div class="chart-body">
        <div id="pagepiling">
            <div class="section">Some section</div>
            <div class="section">Some section</div>
            <div class="section">Some section</div>
            <div class="section">Some section</div>
        </div>
    </div>
    <div class="chart-foot"></div>
</div>
    <script>
        (function ($) {
            $('#pagepiling').pagepiling();
        })(jQuery);
    </script>