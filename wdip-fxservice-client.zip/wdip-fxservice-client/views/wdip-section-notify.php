<?php
use WDIP\Plugin\Services;
?>

<p class="description"><?= __('Please fill following information about account registration onto <a href="https://www.myfxbook.com">https://www.myfxbook.com</a>', Services::config()->OPTIONS_PAGE['menu_slug']); ?></p>